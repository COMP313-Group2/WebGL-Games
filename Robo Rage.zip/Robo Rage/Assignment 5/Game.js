/*
Assignment 5: Robo Rage Game
Lyle Spurrell | 300898504
*/

// Game objects
var isMainMenu = true;
var isMainMenuOnce = true;
var isPlayedOnce = true;
var buttonNum;
var isInstructions = false;
var isGame = false;
var isFirstScore = true;

var num = 0;
var num2 = 0;

var robotImgs = [];
var robotClones = [];
var robot = {
    x: 0,
    y: 0
};
var dropSpeed = 8;
var isFirstSpwan = true;
var isDestroyed = false;
var strikes = 0;
var killStreak = 0;
var highestKillStreakCounter = 0;
var highestKillStreak = 0;
var points = 0;
var blueRobots = 0;
var pinkRobots = 0;
var orangeRobots = 0;
var robotsDestroyed = 0;
var robotsMissed = 0;
var robotsSpawned = 0;
var clicks = 0;
var gameTime = 59;
var milliSec = 3000;
var timer;

var playBackSpeed = 0.5;
var playBackSpeed2 = 1.5;
var playBackSpeed3 = 1.5;

var mainMenuMusic = new Audio("Audios/Metal_Arms_Main_Menu_Theme.mp3");
mainMenuMusic.loop = true;
var hoverSound = new Audio("Audios/Robot_blip.mp3");
var spawnRobotSound = new Audio("Audios/Robot_blip_2.mp3");
var brokenRobotSound = new Audio("Audios/Metal_Clang.wav");
brokenRobotSound.playbackRate = playBackSpeed2;
var brokenRobotSound2 = new Audio("Audios/Fizzle_Sound.wav");
brokenRobotSound2.playbackRate = playBackSpeed3;
var airHorn = new Audio("Audios/Air_Horn.mp3");

// Create the canvas
var canvas = document.createElement("canvas");
canvas.id = "canvas";
var context2D = canvas.getContext("2d");
canvas.width = 960;
canvas.height = 480;
canvas.addEventListener("mousemove", mouseMove, false);
canvas.addEventListener("click", canvasClickCheck, false);
document.getElementsByTagName("main")[0].appendChild(canvas);

// Background image
var backgroundReady = false;
var backgroundImage = new Image();
backgroundImage.onload = function () {
    backgroundReady = true;
};
backgroundImage.src = "Images/junkyard_level_small2.png";

// Text Background image
var textBackgroundReady = false;
var textBackgroundImage = new Image();
textBackgroundImage.onload = function () {
    textBackgroundReady = true;
};
textBackgroundImage.src = "Images/Text_Background2.png";

// Start Button Background image
var startBtnBackgroundReady = false;
var startBtnBackgroundImage = new Image();
startBtnBackgroundImage.onload = function () {
    startBtnBackgroundReady = true;
};
startBtnBackgroundImage.src = "Images/Button_Background.png";

// Instructions Button Background image
var instructionsBtnBackgroundReady = false;
var instructionsBtnBackgroundImage = new Image();
instructionsBtnBackgroundImage.onload = function () {
    instructionsBtnBackgroundReady = true;
};
instructionsBtnBackgroundImage.src = "Images/Button_Background.png";

// Exit Button Background image
var exitBtnBackgroundReady = false;
var exitBtnBackgroundImage = new Image();
exitBtnBackgroundImage.onload = function () {
    exitBtnBackgroundReady = true;
};
exitBtnBackgroundImage.src = "Images/Button_Background.png";

// Back Button Background image
var backBtnBackgroundReady = false;
var backBtnBackgroundImage = new Image();
backBtnBackgroundImage.onload = function () {
    backBtnBackgroundReady = true;
};
backBtnBackgroundImage.src = "Images/Button_Background.png";

// robot image
var robotReady = false;
var robotImage = new Image();
robotImage.onload = function () {
    robotReady = true;
};
robotImage.src = "Images/Robot3.png";

//______________________________________________________ Functions _____________________________________________________________

// Getting the mouse position based on canvas
function getMousePosition(event) {
    var rect = canvas.getBoundingClientRect();
    return {
        x: event.clientX - rect.left,
        y: event.clientY - rect.top
    };
}

// Reset the location of the Robot when clicked
function resetRobotPosition() {

    if (isGame == true) {
        if (isFirstSpwan == false) {
            if (isDestroyed == false) {
                robotsMissed++;
                strikes++;
                if (highestKillStreak < highestKillStreakCounter) {
                    highestKillStreak = highestKillStreakCounter;
                }
                highestKillStreakCounter = 0;
                if (killStreak > 0) {
                    killStreak--;
                }
            }
            else {
                isDestroyed = false;
            }
            if (strikes == 3) {
                milliSec = 3000;
                playBackSpeed = 0.5;
                spawnRobotSound.playbackRate = playBackSpeed;
                strikes = 0;
            }
        }
        else {
            isFirstSpwan = false;
        }

        if (milliSec <= 1000 && milliSec >= 800) {
            robotImage.src = "Images/Robot5.png";
        }
        else if (milliSec <= 1800 && milliSec > 1000) {
            robotImage.src = "Images/Robot4.png";
        }
        else {
            robotImage.src = "Images/Robot3.png";
        }

        spawnRobotSound.play();
    }


    if (isGame == true || isMainMenu == true) {
        // Place the robot somewhere on the canvas    
        robot.x = (Math.random() * (canvas.width - 50));
        robot.y = (Math.random() * (canvas.height - 52));

        setTimer();
    }
}

// Sets the timer
function setTimer() {
    window.clearTimeout(timer);
    timer = window.setTimeout(resetRobotPosition, milliSec);
}

// Reset and go back to main menu
function resetAll() {

    isMainMenu = true;
    isMainMenuOnce = true;
    isPlayedOnce = true;
    isInstructions = false;
    isGame = false;
    isFirstScore = true;

    num = 0;
    num2 = 0;

    robotImgs = [];
    robotClones = [];

    isFirstSpwan = true;
    isDestroyed = false;
    strikes = 0;
    killStreak = 0;
    highestKillStreakCounter = 0;
    highestKillStreak = 0;
    points = 0;
    blueRobots = 0;
    pinkRobots = 0;
    orangeRobots = 0;
    robotsDestroyed = 0;
    robotsMissed = 0;
    robotsSpawned = 0;
    clicks = 0;
    gameTime = 59;
    milliSec = 3000;

    playBackSpeed = 0.5;

    spawnRobotSound.playbackRate = playBackSpeed;
}

// Creates a sound when the mouse is over a button
function mouseMove() {

    var mousePosition = getMousePosition(event);
    var isOffButton = true;
    var buttonNumCopy = buttonNum + '';

    if (isMainMenu == true) {

        // Start Button
        if (mousePosition.x <= (330 + 300) && mousePosition.y <= (180 + 40) && mousePosition.x >= (330) && mousePosition.y >= (180)) {
            startBtnBackgroundImage.src = "Images/Button_Background2.png";
            isOffButton = false;
        }
        else {
            startBtnBackgroundImage.src = "Images/Button_Background.png";
        }

        // Instructions Button 
        if (mousePosition.x <= (330 + 300) && mousePosition.y <= (235 + 40) && mousePosition.x >= (330) && mousePosition.y >= (235)) {
            instructionsBtnBackgroundImage.src = "Images/Button_Background2.png";
            isOffButton = false;
        }
        else {
            instructionsBtnBackgroundImage.src = "Images/Button_Background.png";
        }

        // Exit Button
        if (mousePosition.x <= (330 + 300) && mousePosition.y <= (290 + 40) && mousePosition.x >= (330) && mousePosition.y >= (290)) {
            exitBtnBackgroundImage.src = "Images/Button_Background2.png";
            isOffButton = false;
        }
        else {
            exitBtnBackgroundImage.src = "Images/Button_Background.png";
        }

        if (isOffButton == false) {
            //document.getElementById("canvas").style.cursor = "pointer";
            buttonNum = '1';
        }
        else {
            //document.getElementById("canvas").style.cursor = "default";
            buttonNum = '0';
        }

        if (buttonNum == '1' && buttonNumCopy != buttonNum) {
            hoverSound.play();
        }
    }

    else if (isInstructions == true) {

        // Back Button
        if (mousePosition.x <= (325 + 300) && mousePosition.y <= (405 + 40) && mousePosition.x >= (325) && mousePosition.y >= (405)) {
            if (isPlayedOnce == true) {
                hoverSound.play();
                isPlayedOnce = false;
            }
            backBtnBackgroundImage.src = "Images/Button_Background2.png";
            //document.getElementById("canvas").style.cursor = "pointer";
        }
        else {
            backBtnBackgroundImage.src = "Images/Button_Background.png";
            //document.getElementById("canvas").style.cursor = "default";
            isPlayedOnce = true;
        }
    }

    else if (isGame == true) {
        if (mousePosition.x <= (robot.x + 50) && mousePosition.y <= (robot.y + 52) && mousePosition.x >= (robot.x) && mousePosition.y >= (robot.y)) {
            //document.getElementById("canvas").style.cursor = "pointer";
        }
        else {
            //document.getElementById("canvas").style.cursor = "default";
        }
    }

    else {

        // Back Button
        if (mousePosition.x <= (325 + 300) && mousePosition.y <= (405 + 40) && mousePosition.x >= (325) && mousePosition.y >= (405) && isGame == false) {
            if (isPlayedOnce == true) {
                hoverSound.play();
                isPlayedOnce = false;
            }
            backBtnBackgroundImage.src = "Images/Button_Background2.png";
            //document.getElementById("canvas").style.cursor = "pointer";
        }
        else {
            backBtnBackgroundImage.src = "Images/Button_Background.png";
            //document.getElementById("canvas").style.cursor = "default";
            isPlayedOnce = true;
        }
    }
}

// For mouse clicks
function canvasClickCheck() {

    var mousePosition = getMousePosition(event);

    if (isMainMenu == true) {

        backBtnBackgroundImage.src = "Images/Button_Background.png";

        // Start Button
        if (mousePosition.x <= (330 + 300) && mousePosition.y <= (180 + 40) && mousePosition.x >= (330) && mousePosition.y >= (180)) {
            //alert(mousePosition.x + " <= " + (330 + 300) + " && " + mousePosition.y + " <= " + (180 + 40) + " && " + mousePosition.x + " >= " + (330) + " && " + mousePosition.y + " >= " + (180));
            isMainMenu = false;
            isGame = true;
            resetRobotPosition();
        }

        // Instructions Button 
        if (mousePosition.x <= (330 + 300) && mousePosition.y <= (235 + 40) && mousePosition.x >= (330) && mousePosition.y >= (235)) {
            isMainMenu = false;
            isInstructions = true;
        }

        // Exit Button
        if (mousePosition.x <= (330 + 300) && mousePosition.y <= (290 + 40) && mousePosition.x >= (330) && mousePosition.y >= (290)) {
            window.close();
        }
    }

    else if (isInstructions == true) {

        startBtnBackgroundImage.src = "Images/Button_Background.png";
        instructionsBtnBackgroundImage.src = "Images/Button_Background.png";
        exitBtnBackgroundImage.src = "Images/Button_Background.png";

        // Back Button
        if (mousePosition.x <= (325 + 300) && mousePosition.y <= (405 + 40) && mousePosition.x >= (325) && mousePosition.y >= (405)) {
            resetAll();
        }
    }

    else if (isGame == true) {
        destroyRobotCheck();
    }

    else {

        startBtnBackgroundImage.src = "Images/Button_Background.png";
        instructionsBtnBackgroundImage.src = "Images/Button_Background.png";
        exitBtnBackgroundImage.src = "Images/Button_Background.png";

        // Back Button
        if (mousePosition.x <= (325 + 300) && mousePosition.y <= (405 + 40) && mousePosition.x >= (325) && mousePosition.y >= (405)) {
            resetAll();
        }
    }
}

// Check is mouse is on robot
function destroyRobotCheck() {

    var mousePosition = getMousePosition(event);

    if (isGame == true) {
        clicks++;

        if (mousePosition.x <= (robot.x + 50) && mousePosition.y <= (robot.y + 52) && mousePosition.x >= (robot.x) && mousePosition.y >= (robot.y)) {

            robotImgs[num] = new Image();
            robotImgs[num].src = "Images/Robot2.png";
            robotClones[num2] = Number(robot.x + "");
            robotClones[num2 + 1] = Number(robot.y + "");
            num++;
            num2 += 2;
            robotsDestroyed++;
            killStreak++;
            highestKillStreakCounter++;
            isDestroyed = true;

            if (milliSec <= 1000 && milliSec >= 800) {
                points += 50;
                orangeRobots++;
            }
            else if (milliSec <= 1800 && milliSec > 1000) {
                points += 25;
                pinkRobots++;
            }
            else {
                points += 10;
                blueRobots++;
            }

            if (killStreak == 3) {
                if ((milliSec - 200) >= 800) {
                    milliSec -= 200;                                //200 for game and 2200 for testing 
                    playBackSpeed += 0.1;
                    spawnRobotSound.playbackRate = playBackSpeed;
                }
                killStreak = 0;
            }

            brokenRobotSound.play();
            brokenRobotSound.onended = function () {
                brokenRobotSound2.play();
            };

            resetRobotPosition();
        }
    }
}

// Moves dead robots down
function deadRobot() {
    var num = 0;
    var num2 = 0;
    while (robotImgs[num] != null) {
        robotClones[num2 + 1] += dropSpeed;
        num++;
        num2 += 2;
    }
}

//_____________________________________________________ Rendering  _____________________________________________________________

// Displays the main menu
function renderMainMenu() {

    mainMenuMusic.play();

    if (isMainMenuOnce == true) {
        isMainMenuOnce = false;
        robotImage.src = "Images/Robot3.png";
        resetRobotPosition();
    }

    if (robotReady) {
        context2D.drawImage(robotImage, robot.x, robot.y);
    }

    if (textBackgroundReady) {
        context2D.drawImage(textBackgroundImage, 305, 15);
    }

    if (startBtnBackgroundReady) {
        context2D.drawImage(startBtnBackgroundImage, 330, 180);
    }

    if (instructionsBtnBackgroundReady) {
        context2D.drawImage(instructionsBtnBackgroundImage, 330, 235);
    }

    if (exitBtnBackgroundReady) {
        context2D.drawImage(exitBtnBackgroundImage, 330, 290);
    }

    // Title
    context2D.fillStyle = "rgb(250, 250, 250)";
    context2D.font = "60px Helvetica";
    context2D.textAlign = "center";
    context2D.textBaseline = "top";
    context2D.fillText("Robo Rage", 480, 50);

    context2D.textAlign = "center";
    context2D.font = "22px Helvetica";
    context2D.fillText("Start", 480, 190);
    context2D.fillText("Instructions", 480, 245);
    context2D.fillText("Exit", 480, 300);
};

// Displays the Instructions
function renderInstructions() {

    if (textBackgroundReady) {
        context2D.drawImage(textBackgroundImage, 305, 15);
    }

    if (backBtnBackgroundReady) {
        context2D.drawImage(backBtnBackgroundImage, 325, 405);
    }

    context2D.fillStyle = "rgb(250, 250, 250)";
    context2D.textBaseline = "top";
    context2D.textAlign = "left";
    context2D.font = "bold 16px Helvetica";
    context2D.fillText("Mission Briefing:", 325, 30);
    context2D.font = "16px Helvetica";
    context2D.fillText("Destroy as many robots as possible", 325, 50);
    context2D.fillText("before the timer runs out!", 325, 70);
    context2D.fillText("", 325, 90);

    context2D.font = "bold 16px Helvetica";
    context2D.fillText("Rules:", 325, 110);
    context2D.font = "16px Helvetica";
    context2D.fillText("Killing 3 robots in a row will increase the", 325, 130);
    context2D.fillText("speed at which the next one respawns at.", 325, 150);
    context2D.fillText("Missing 3 robots will reset the respawn", 325, 170);
    context2D.fillText("speed back to the original state.", 325, 190);
    context2D.fillText("", 325, 210);

    context2D.font = "bold 16px Helvetica";
    context2D.fillText("Points:", 325, 230);
    context2D.font = "16px Helvetica";
    context2D.fillText("1 Blue Robot = 10 pts", 325, 250);
    context2D.fillText("1 Pink Robot = 25 pts", 325, 270);
    context2D.fillText("1 Orange Robot = 50 pts", 325, 290);

    context2D.font = "22px Helvetica";
    context2D.textAlign = "center";
    context2D.fillText("Back", 480, 415);
}

// Displays the game
function renderGame() {

    var now = Date.now();

    if (now - then >= 1000) {
        if (gameTime == 0) {                 // 0 for game
            mainMenuMusic.pause();
            mainMenuMusic.currentTime = 0;

            if (isDestroyed == false) {
                robotsMissed++;
                strikes++;
                if (highestKillStreak < highestKillStreakCounter) {
                    highestKillStreak = highestKillStreakCounter;
                }
                highestKillStreakCounter = 0;
                if (killStreak > 0) {
                    killStreak--;
                }
            }
            window.clearTimeout(timer);
            isGame = false;
        }
        else {
            then = Date.now();
            gameTime--;
        }
    }


    var num = 0;
    var num2 = 0;

    while (robotImgs[num] != null) {
        context2D.drawImage(robotImgs[num], robotClones[num2], robotClones[num2 + 1]);
        num++;
        num2 += 2;
    }

    if (robotReady) {
        context2D.drawImage(robotImage, robot.x, robot.y);
    }

    // Info    
    context2D.fillStyle = "rgb(250, 250, 250)";
    context2D.font = "22px Helvetica";
    context2D.textAlign = "left";
    context2D.textBaseline = "top";
    context2D.fillText("Points: " + points, 20, 440);

    context2D.textAlign = "center";
    context2D.fillText("Time: " + gameTime + " s", 480, 440);

    // Tests
    //robotsSpawned = robotsDestroyed + robotsMissed;
    //context2D.fillText("Missed: " + robotsMissed, 250, 440);
    //context2D.fillText("Kill streak: " + killStreak, 400, 440);
    //context2D.fillText("Strikes: " + (strikes), 550, 440);
    //context2D.fillText("milliSec: " + milliSec, 700, 440);
    //context2D.fillText("Timer: " + timer, 850, 440);
};

// Displays the score
function renderScore() {

    if (isFirstScore == true) {
        airHorn.play();
        isFirstScore = false;
    }

    var accuracyPercentage;

    var pointsRanking;
    var pointsNum;
    var robotsDestroyedRanking;
    var robotsDestroyedNum;
    var highestKillStreakRanking;
    var highestKillStreakNum;
    var accuracyPercentageRanking;
    var accuracyPercentageNum;

    var overallNum;
    var overallRanking;
    var title;

    // Points Ranking
    if (points >= 2000) {
        pointsRanking = 'S';
        pointsNum = 5;
    }
    else if (points >= 1500 && points < 2000) {
        pointsRanking = 'A';
        pointsNum = 4;
    }
    else if (points >= 1000 && points < 1500) {
        pointsRanking = 'B';
        pointsNum = 3;
    }
    else if (points >= 500 && points < 1000) {
        pointsRanking = 'C';
        pointsNum = 2;
    }
    else {
        pointsRanking = 'D';
        pointsNum = 1;
    }

    robotsSpawned = robotsDestroyed + robotsMissed;

    // Destroyed Ranking
    if (robotsDestroyed >= 80) {
        robotsDestroyedRanking = 'S';
        robotsDestroyedNum = 5;
    }
    else if (robotsDestroyed >= 70 && robotsDestroyed < 80) {
        robotsDestroyedRanking = 'A';
        robotsDestroyedNum = 4;
    }
    else if (robotsDestroyed >= 60 && robotsDestroyed < 70) {
        robotsDestroyedRanking = 'B';
        robotsDestroyedNum = 3;
    }
    else if (robotsDestroyed >= 50 && robotsDestroyed < 60) {
        robotsDestroyedRanking = 'C';
        robotsDestroyedNum = 2;
    }
    else {
        robotsDestroyedRanking = 'D';
        robotsDestroyedNum = 1;
    }

    // Highest Kill Streak Ranking
    if (highestKillStreak >= 30) {
        highestKillStreakRanking = 'S';
        highestKillStreakNum = 5;
    }
    else if (highestKillStreak >= 25 && highestKillStreak < 30) {
        highestKillStreakRanking = 'A';
        highestKillStreakNum = 4;
    }
    else if (highestKillStreak >= 20 && highestKillStreak < 25) {
        highestKillStreakRanking = 'B';
        highestKillStreakNum = 3;
    }
    else if (highestKillStreak >= 15 && highestKillStreak < 20) {
        highestKillStreakRanking = 'C';
        highestKillStreakNum = 2;
    }
    else {
        highestKillStreakRanking = 'D';
        highestKillStreakNum = 1;
    }

    if (clicks == 0) {
        accuracyPercentage = 0;
    }
    else {
        accuracyPercentage = (robotsDestroyed / clicks) * 100;
        accuracyPercentage = Math.round(accuracyPercentage * 10) / 10;
    }

    // Accuracy Ranking
    if (accuracyPercentage >= 80) {
        accuracyPercentageRanking = 'S';
        accuracyPercentageNum = 5;
    }
    else if (accuracyPercentage >= 70 && accuracyPercentage < 80) {
        accuracyPercentageRanking = 'A';
        accuracyPercentageNum = 4;
    }
    else if (accuracyPercentage >= 60 && accuracyPercentage < 70) {
        accuracyPercentageRanking = 'B';
        accuracyPercentageNum = 3;
    }
    else if (accuracyPercentage >= 50 && accuracyPercentage < 60) {
        accuracyPercentageRanking = 'C';
        accuracyPercentageNum = 2;
    }
    else {
        accuracyPercentageRanking = 'D';
        accuracyPercentageNum = 1;
    }

    // Calculating Overall Ranking
    overallNum = Math.round((pointsNum + robotsDestroyedNum + highestKillStreakNum + accuracyPercentageNum) / 4);

    if (overallNum == 5) {
        overallRanking = 'S';
        title = "Legendary Robot Slayer"
    }
    else if (overallNum == 4) {
        overallRanking = 'A';
        title = "Expert Robot Killer";
    }
    else if (overallNum == 3) {
        overallRanking = 'B';
        title = "Bot Grinder";
    }
    else if (overallNum == 2) {
        overallRanking = 'C';
        title = "Survivor";
    }
    else {
        overallRanking = 'D';
        title = "Scrap Metal";
    }



    if (textBackgroundReady) {
        context2D.drawImage(textBackgroundImage, 300, 15);
    }

    if (backBtnBackgroundReady) {
        context2D.drawImage(backBtnBackgroundImage, 325, 405);
    }

    context2D.fillStyle = "rgb(250, 250, 250)";
    context2D.font = "30px Helvetica";
    context2D.textAlign = "center";
    context2D.textBaseline = "top";
    context2D.fillText("Score ", 480, 30);

    context2D.textAlign = "left";
    context2D.font = "18px Helvetica";
    context2D.fillText("Points:", 325, 75);
    context2D.fillText(points, 525, 75);
    context2D.fillText(pointsRanking, 605, 75);
    context2D.fillText("Blue robots:", 325, 100);
    context2D.fillText(blueRobots, 525, 100);
    context2D.fillText("Pink robots:", 325, 125);
    context2D.fillText(pinkRobots, 525, 125);
    context2D.fillText("Orange robots:", 325, 150);
    context2D.fillText(orangeRobots, 525, 150);
    context2D.fillText("Destroyed:", 325, 175);
    context2D.fillText(robotsDestroyed, 525, 175);
    context2D.fillText(robotsDestroyedRanking, 605, 175);
    context2D.fillText("Missed:", 325, 200);
    context2D.fillText(robotsMissed, 525, 200);
    context2D.fillText("Total spawned:", 325, 225);
    context2D.fillText(robotsSpawned, 525, 225);
    context2D.fillText("Highest kill streak:", 325, 250);
    context2D.fillText(highestKillStreak, 525, 250);
    context2D.fillText(highestKillStreakRanking, 605, 250);
    context2D.fillText("Hits:", 325, 275);
    context2D.fillText(clicks, 525, 275);
    context2D.fillText("Accuracy:", 325, 300);
    context2D.fillText(accuracyPercentage + "%", 525, 300);
    context2D.fillText(accuracyPercentageRanking, 605, 300);
    context2D.fillText("Overall ranking:", 325, 325);
    context2D.fillText(overallRanking, 525, 325);

    context2D.textAlign = "center";
    context2D.fillText("* " + title + " *", 480, 370);
    context2D.font = "22px Helvetica";
    context2D.fillText("Back", 480, 415);
}

//________________________________________________________ Main ________________________________________________________________

// The main game loop
function main() {

    if (backgroundReady) {
        context2D.drawImage(backgroundImage, 0, 0);
    }

    if (isMainMenu == true) {
        renderMainMenu();
    }

    else if (isInstructions == true) {
        renderInstructions();
    }

    else if (isGame == true) {
        deadRobot();
        renderGame();
    }

    else {
        renderScore();
    }

    requestAnimationFrame(main);
};

// Cross-browser support for requestAnimationFrame
var w = window;
requestAnimationFrame = w.requestAnimationFrame || w.webkitRequestAnimationFrame || w.msRequestAnimationFrame || w.mozRequestAnimationFrame;

// Play the game!
var then = Date.now();
main();




